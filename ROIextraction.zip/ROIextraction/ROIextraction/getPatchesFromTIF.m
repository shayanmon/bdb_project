%% Create patches of size 2000x2000 from benign WSIs at 40X
addpath(genpath('D:\Shayan\openslide-3.4.1'));
addpath(genpath('D:\Shayan\openslide-win64-20171122'));
addpath(genpath('D:\Shayan\fordanic-openslide-matlab-240c223'));

tifImages = dir('Z:\data\UH_BileDuct\Scans_10th_March\*.tif');
outputPath = 'Z:\data\UH_BileDuct\Scans_10th_March\Benign_Patches\';

mal = [5,6,7,8,11,15,17,25,37,39,43,48,49,50,53,60,64,65,69,72,75,77,79,81,83,85,87,88,92,93,97];
exclusion_set = [13,14,16,23,24,26,27,29,30,31,32,33,41,45,46,54,59,62,71,74,82,89,91,99,100];
inclusion_set = setdiff(1:102,exclusion_set);
ben = setdiff(inclusion_set,mal);

patchSize = 2000;
clusterAreaThresh = 1000;    %area in microns

for i = 44
    imName = tifImages(i).name;
    nameIndex = strfind(imName, '.');
    patientName = imName(1:nameIndex(1)-1);
    
    if ismember(str2double(patientName),ben)
    
    slidePtr = openslide_open(['Z:\data\UH_BileDuct\Scans_10th_March\' imName]);
    [baseMPP,mppY,width,height,downsampleFactors] = openslide_get_slide_properties(slidePtr);
    
    %Use 6000X6000 window with the same center as the WSI to extract 9 patches
    Xstart = 40000;%width/2 - 3000;
    Ystart = 70000;%height/2 - 3000;
    Xend = 49000;%width/2 + 3000 - patchSize;
    Yend = 79000;%height/2 + 3000 - patchSize;
    level = 0;
    patchNum = 0;
    
    disp(['Working on Patient ' num2str(patientName)]);
    
    for x = Xstart:patchSize:Xend
        for y = Ystart:patchSize:Yend
            patchNum = patchNum + 1;
            
            slideread = openslide_read_region(slidePtr,x,y,patchSize,patchSize,'level',level);
            rgb = slideread(:,:,2:4);
            mask = rgb2gray(rgb) < 200;
            mask = bwareafilt(mask,2);
            cluster_label = bwlabel(mask);
            cluster_areas = regionprops(cluster_label, 'Area');
            cluster_areas = [cluster_areas.Area].' .* baseMPP;
            % ignore clusters smaller than 100microns in area
            if isempty(cluster_areas)
                continue
            end
            if(cluster_areas(1) > clusterAreaThresh)
                if(length(cluster_areas) > 1)
                    if(cluster_areas(2) < clusterAreaThresh)
                        mask = bwareafilt(mask,1);
                        rgb_proc = rgb .* uint8(mask);
                    else
                        rgb_proc = rgb .* uint8(mask);
                    end
                end
            else
                continue
            end
            
            imwrite(rgb_proc, [outputPath patientName '_Patch_' num2str(patchNum) '.tif']);
            %imshow(rgb);
        end
    end
    else
        disp("Not a malignant patient")
        continue
    end
   
end

%% Randomly select validation sets 1 and 2

mal = [5,6,7,8,11,15,17,25,37,39,43,48,49,50,53,60,64,65,69,72,75,77,79,81,83,85,87,88,92,93,97];
exclusion_set = [13,14,16,23,24,26,27,29,30,31,32,33,34,41,45,46,47,51,52,54,57,59,62,66,68,71,74,76,82,89,90,91,99,100];
inclusion_set = setdiff(1:102,exclusion_set);
ben = setdiff(inclusion_set,mal);

% get the randomly-selected indices
mal_indices = randperm(round(0.5*length(mal)));
ben_indices = randperm(round(0.5*length(ben)));

valSet1 = [mal(mal_indices) ben(ben_indices)];
valSet2 = setdiff(inclusion_set,valSet1);
save('valSet1_idx.mat','valSet1')
save('valSet2_idx.mat','valSet2')

val_output = 'D:\Shayan\Bile_Brushing_Cytology\Validation_Set';
set1_output = 'D:\Shayan\Bile_Brushing_Cytology\Validation_Set\Set1';
set2_output = 'D:\Shayan\Bile_Brushing_Cytology\Validation_Set\Set2';

valImages = dir([val_output '\*.tif']);

for j = 1:length(valImages)
    curName = valImages(j).name;
    nameIndex = strfind(curName, '_');
    patientName = curName(1:nameIndex(1)-1);
    patientName = str2double(patientName);
    
    if ismember(patientName,valSet1)
        movefile([val_output filesep curName] ,[set1_output filesep curName]);
    elseif ismember(patientName,valSet2)
        movefile([val_output filesep curName] ,[set2_output filesep curName]);
    end
end
