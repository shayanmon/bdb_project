addpath(genpath('D:\Shayan\openslide-3.4.1'));
addpath(genpath('D:\Shayan\openslide-win64-20171122'));
addpath(genpath('D:\Shayan\fordanic-openslide-matlab-240c223'));
addpath(genpath('D:\Shayan\Util-master\ROIextraction'));

tifFiles = dir('Z:\data\UH_BileDuct\Scans_10th_March\*.tif');
xmlDir = 'Z:\data\UH_BileDuct\Scans_10th_March\Malignant_Patches';
outputPath = 'D:\Shayan\Bile_Brushing_Cytology\Validation_Set';
%% Obtain clusters as tif files from annotations

for f = 1:length(tifFiles)
    imgPath = [tifFiles(f).folder filesep tifFiles(f).name];
    xmlPath = [xmlDir filesep tifFiles(f).name(1:end-4) '.xml'];
    if exist(xmlPath,'file')
        annos = getRegionsOfAnnotation(xmlPath);
        annos = annos{2}; % All annotations will be in {2}
        mpp = [0.25];
        for k = 1:length(annos)
            count = 0;
            for m = mpp
                count = count + 1;
                [rgb, mask] = getROIfromTif(imgPath,annos(k),mpp(count));
%                 B = bwboundaries(mask);
%                 B = cell2mat(B);
%                 borderpix = boundary(B);
%                 maskBorder = B(borderpix,:);
%                 mask = poly2mask(maskBorder(:,2),maskBorder(:,1),size(rgb,1),size(rgb,2));
                
                anno_x  = annos(k).X;
                anno_y = annos(k).Y;
                min_x = min(anno_x);
                min_y = min(anno_y);
                
                mask = poly2mask(anno_x-min_x, anno_y-min_y, size(rgb,1),size(rgb,2));
                rgb = rgb .* uint8(repmat(mask,1,1,size(rgb,3)));
                rgb = rgb + uint8(repmat(~mask,1,1,3))*255;
                imwrite(rgb,[outputPath filesep tifFiles(f).name(1:end-4) '_Cluster' num2str(k) '.tif']);
            end
        end
    end
end