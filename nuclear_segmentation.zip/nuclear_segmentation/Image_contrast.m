
% Input: RGB image
% Output: Blue channel enhanced contrast
function [blue_contrasted] = Image_contrast(im)
    % get rid of background
    blue=im(:,:,3);
    mask_bg=blue>200;
    figure; imshow(mask_bg);
    figure;imshow(blue);

    set_foregroundpixelintesity=blue(~mask_bg);
    set_foregroundpixel_idx=find(~mask_bg);
    %figure;histogram(set_foregroundpixelintesity);

    %%
    my_limit=0.1;
    low_limit=0.008;
    up_limit=0.992;
    %----------------------------------------------------------------------
    img=blue;
    [m1, n1, r1]=size(img);
    %----------------------------------------------------------------------
    a=double(img)./255;
    a=a(~mask_bg);
    %----------------------------------------------------------------------
    mean_adjustment=my_limit-mean(mean(a));
    a=a+mean_adjustment*(1-a);
    %----------------------------------------------------------------------
    img=a.*255;
    %--------------------calculation of vmin and vmax----------------------

    arr=sort(img);
    v_min=arr(ceil(low_limit*length(a)));
    v_max=arr(ceil(up_limit*length(a)));

    %----------------------------------------------------------------------
    %----------------------------------------------------------------------
    img=(img-v_min(1))/(v_max(1)-v_min(1));
    ouppixel=uint8(img.*255);
    %% put back into image
    blue_contrasted=blue;
    blue_contrasted(set_foregroundpixel_idx)=ouppixel;
    %figure;subplot(1,2,1);imshow(blue); title('original');
    %subplot(1,2,2);
    %imshow(blue_contrasted);title('contrast enhanced');
end