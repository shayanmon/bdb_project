for l = 1:length(nuclei)
   temp = nuclei{l,1};
   for n = 1:length(temp)
       bounds(l).r = temp(:,1);
       bounds(l).c = temp(:,2);
   end
end

%% 
close all
strFolderName = 'D:\Shayan\Bile_Brushing_Cytology\QuPath_Images\XML_Images\';
curIMName=tifFiles(99).name;
curIM=imread([strFolderName curIMName]);

mask = logical(seg_mask);
img = curIM;
invs = [properties.Circularity];

        cmapoverlay.r=zeros(size(img,1), size(img,2));
        cmapoverlay.g=zeros(size(img,1), size(img,2));
        cmapoverlay.b=zeros(size(img,1), size(img,2));
         
        invs = rescale(invs);
        tdat = round(invs * 254);
        
        
        if(exist('cbrewer.m','file'))
            cmap = flipud(cbrewer('div','RdYlBu',255));
        else
            cmap = linspecer(255);
        end
        
        for k1=27:29
            
            tmask=bounds2mask(bounds(k1),img);
            
            %             tdat(k1)=round((invs(k1)-n.min)/(n.max-n.min)*255);
            
            
            colormapped=ind2rgb(tdat(k1), cmap);
                % for k2=1:3
            cmapoverlay.r(tmask)=colormapped(1,1,1);
            cmapoverlay.g(tmask)=colormapped(1,1,2);
            cmapoverlay.b(tmask)=colormapped(1,1,3);
                % end
        end
        
        
        cmovrly=zeros(size(img,1), size(img,2),3);
        cmovrly(:,:,1)=cmapoverlay.r;
        cmovrly(:,:,2)=cmapoverlay.g;
        cmovrly(:,:,3)=cmapoverlay.b;
        cmovrly=cmovrly*255;
        
        
        imgtemp=img;
        
        assignin('base','cmovrly',cmovrly)
        assignin('base','mask',tmask)
        assignin('base','imgtemp',imgtemp)
        assignin('base','img',img)
        
        
        for k1=1:size(img,1)
            for k2=1:size(img,2)
                if cmovrly(k1,k2,1)>0
                    imgtemp(k1,k2,:)=cmovrly(k1,k2,:);
                end
            end
        end
        imshow(imgtemp)