addpath(genpath('./veta_watershed'));
addpath(genpath('./GeneralLoG'));
addpath(genpath('./staining_normalization'));
addpath(genpath('D:\ Shayan\Bile_Brushing_Cytology\Nuclear Segmentation\Utilities-master\Utilities-master'));
addpath(genpath('D:\Shayan\Util-master\nuclei_seg_cytology'));
%dbstop if error
%% Training set images
strFolderName = 'D:\Shayan\Bile_Brushing_Cytology\Training_Set\XML_Images\';
%strFolderName = 'D:\Shayan\Bile_Brushing_Cytology\QuPath_Images\Malignant_Images\';
%strFolderName = 'D:\Shayan\Util-master\nuclei_seg_cytology\';
tifFiles = dir([strFolderName '*.tif']);
%% Validation set 1 images
strFolderName = 'D:\Shayan\Bile_Brushing_Cytology\Validation_Set\';
tifFiles = dir([strFolderName '*.tif']);

%% Begin nuclear segmentation
for i=427:length(tifFiles)
    close all

    curIMName=tifFiles(i).name;
    curIM=imread([strFolderName curIMName]);
    
    disp(['Opening image ' num2str(i)])
    
    %[curIM_norm] = normalizeStaining(curIM);
    for idx = find(curIM == 0)
        curIM(idx) = 255;
    end
    contEnhanced_curIM = Image_contrast(curIM);
    %curIM_normBlue=curIM(:,:,3); %1 is red, 2 is green, 3 is blue channel
    %% using gLoG-Watershed
    
    % apply different scales for benign and malignant (typically larger) nuclei
    if contains(curIMName,"Cluster")
        res.scales = 12:2:18;   % increase range for large nuclear size variation
    else
        res.scales = 6:2:10;
    end

    disp('begin nuclei segmentation using watershed');
    [nuclei, ~] = nucleiSegmentationV2_gLoG(contEnhanced_curIM,res);
    
    close(figure(3),figure(4),figure(5))
    
    fig = figure(1);imshow(curIM);
    hold on;
    for k = 1:length(nuclei)
        plot(nuclei{k}(:,2), nuclei{k}(:,1), 'g-', 'LineWidth', 2);
    end 
    %saveas(fig,['D:\Shayan\Bile_Brushing_Cytology\Nuclear Segmentation\Validation_Set\Segmentation_Images\' curIMName(1:end-4) '_nuclei.tif']);
    hold off;
    
    %nuclei binary mask
     fig2 = figure(2); seg_mask = Lnuclei2mask(contEnhanced_curIM,nuclei);
     %LshowBWonIM(seg_mask,conEnhanced_curIM,1);
     imshow(seg_mask)
     imwrite(seg_mask,['D:\Shayan\Bile_Brushing_Cytology\Training_Set\Nuclear_Segmentation\Nuclear_masks\' curIMName(1:end-4) '_nuclear_mask.tif']);

     %cytoplasm mask
     ROImask=contEnhanced_curIM<220;
     ROImask=bwareaopen(ROImask, 50);
     cyto_mask = ROImask-seg_mask;
     fig3 = figure(3); imshow(cyto_mask);
     imwrite(cyto_mask,['D:\Shayan\Bile_Brushing_Cytology\Training_Set\Nuclear_Segmentation\cyto_masks\' curIMName(1:end-4) '_cyto_mask.tif']);

    %save(['D:\Shayan\Bile_Brushing_Cytology\Nuclear Segmentation\Validation_Set\shape_features\' curIMName(1:end-4) '_shapefeats'],'properties');
    
    %% Mean intensity of nuclei
    
%     x = bwlabel(seg_mask);
%     mean_int_nuclei = zeros(length(unique(x)),1);
%     for n = 1:length(unique(x))
%         each_nuclei_mask = x == n;
%         mean_int_nuclei(n) = mean(curIM(each_nuclei_mask));
%     end
    %% using multi resolution watershed, speed up veta
%     
%     p.scales=[6];
%     disp('begin nuclei segmentation using watershed');
%     [nuclei, properties] = nucleiSegmentationV2(curIM_normRed,p);
%     
%     figure;imshow(curIM);hold on;
%     for k = 1:length(nuclei)
%         plot(nuclei{k}(:,2), nuclei{k}(:,1), 'g-', 'LineWidth', 2);
%     end
%     hold off;
%     %% using general LoG, in folder testIM_German/GeneralLoG
%     %%% initial segmentation
%     R=curIM_normRed; I=curIM;
%     ac=30;    % remove isolated pixels(non-nuclei pixels)
% %     show(bwSpot)
% 
%     [Nmask,cs,rs,A3]=XNucleiSeg_GL_Thresholding(R,ac);      %% thresholding based binarization % show(R)
% %     show(Nmask);
%     %%% gLoG seeds detection
%     largeSigma=10;smallSigma=8; % Sigma value
%     ns=XNucleiCenD_Clustering(R,Nmask,largeSigma,smallSigma);  %% To detect nuclei clumps
% %     53 s
%     figure(1),imshow(I(:,:,1));
%     hold on,plot(ns(2,:),ns(1,:),'y+');
%      hold on,plot(cs,rs,'y+');
% %     hold on,plot(cs,rs,'g*');
%     
%     %%% marker-controlled watershed segmentation
% %     ind=sub2ind(size(R),ns(1,:),ns(2,:));
% %     bs4=zeros(size(R));
% %     bs4(ind)=1;
% %     [bnf,blm]=XWaterShed(Nmask,bs4);
% %     
% %     %%% show segmentations
% %     bb=bwperim(Nmask);  % for debugging finial segmentations
% %     ind5=find(bb);
% %     blm(ind5)=1;
% %     bb2=bwperim(A3);
% %     ind6=find(bb2);
% %     blm(ind6)=1;
% %     overlay1=imoverlay(I,blm,[0 1 0]);
% %     figure(2),imshow(overlay1);
end