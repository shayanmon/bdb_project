%bounds2mask
%This program should take a set of boundaries and compute a binary mask
%from it.  

function [BW]=bounds2mask(bounds, image)
% image=imread(filelist(1).paths);
% bounds=vetaout;
% image=imread(image);
[imgheight, imgwidth, ~]=size(image);
BW=false(imgheight, imgwidth);
emptycheck=1;
try 
    if ~isempty(bounds(:,1))
        emptycheck=0;
    end
    varsetup=1;
catch
    try
        if ~isempty(bounds{1}(1,1))
            emptycheck=0;
        end
        varsetup=2;
    catch
        if ~isempty(bounds(1))
            emptycheck=0;
        end
        varsetup=3;
    end
end
if ~emptycheck
    for i=1:length(bounds)
    %     if isstruct(bounds)
            switch varsetup
                case 1
                    if ~isempty(bounds(i).c)
                        newpoly=poly2mask(bounds(i).c, bounds(i).r, imgheight, imgwidth);
                        polyedge=logical(imdilate(newpoly, ones(3,3))-newpoly);
                        BW = logical(BW + newpoly);
                        BW=BW & ~polyedge;
                    end
%             catch
%                 try
                case 2
                    try
                        if ~isempty(bounds{i}(:,2))
                            newpoly=poly2mask(bounds{i}, bounds{i}, imgheight, imgwidth);
                            polyedge=logical(imdilate(newpoly, ones(3,3))-newpoly);
                            BW = logical(BW + newpoly);
                            BW=BW & ~polyedge;
                        end
                    catch
                        if ~isempty(bounds{i})
                            [c1,c2]=ind2sub([size(image,1), size(image,2)],bounds{i});
                            newpoly=poly2mask(c2, c1, imgheight, imgwidth);
                            polyedge=logical(imdilate(newpoly, ones(3,3))-newpoly);
                            BW = logical(BW + newpoly);
                            BW=BW & ~polyedge;
                        end
                    end
                case 3
                    if ~isempty(bounds(i).bounds)
                        newpoly=poly2mask(bounds(i).bounds(:,2), bounds(i).bounds(:,1), imgheight, imgwidth);
                        polyedge=logical(imdilate(newpoly, ones(3,3))-newpoly);
                        BW = logical(BW + newpoly);
                        BW=BW & ~polyedge;
                    end
%                 end
            end
    end
    BW=logical(BW);
end


% figure(2);
% imshow(BW);
% title('BW')